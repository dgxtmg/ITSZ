# BSOFT Kitchen Display — Odoo 17 Community

Pantalla Kanban de cocina con estaciones, filtros por categoría/POS, estados por línea, cronómetro, alertas visuales y grupos de seguridad. Versión `17.0.1.1.0`.

## Alertas de un minuto por etapa

- Cada tarjeta representa una línea del pedido.
- Pendiente, Preparando y Listo tienen su propio contador `mm:ss`.
- Al cumplir **60 segundos en la etapa actual**, la tarjeta se pone roja y emite una señal de dos tonos, una vez por etapa en cada pantalla abierta.
- Al avanzar de etapa, desaparece el rojo y el contador vuelve a cero. Si la siguiente etapa alcanza el minuto, vuelve a ponerse roja y emitir la señal.
- Entregado y Cancelado salen del tablero y dejan de emitir alertas.
- El inicio de etapa se guarda en el servidor; repetir el mismo estado, modificar la cantidad o consultar pedidos no reinicia el contador.
- Se conservan los tiempos históricos al actualizar: los registros anteriores usan la fecha de creación de la línea, de inicio de preparación o de listo, según la etapa, hasta su siguiente transición.
- Los antiguos umbrales de aviso/crítico se conservan en el modelo por compatibilidad, pero no controlan esta regla fija de un minuto ni se muestran en la configuración de estaciones.

Al abrir la pantalla, pulsa **Activar sonido**. El botón habilita el audio mediante una interacción del usuario y emite una señal de prueba. Después cambia a **Probar sonido**. Debes habilitarlo en cada pantalla o pestaña nueva; el navegador puede suspenderlo al recargar. Si hay tarjetas que ya superaron el minuto, se emite una señal al activarlo. Los errores al habilitar el audio se muestran en pantalla.

Activa también **Sonido** en la estación correspondiente. Desactivarlo silencia las alertas automáticas de esa estación; las tarjetas siguen poniéndose rojas. El botón de prueba de sonido sigue disponible. Varias tarjetas que cumplen el minuto simultáneamente producen una sola señal para evitar superposición. La consulta al servidor ocurre cada cinco segundos y el reloj local se actualiza cada segundo; una transición hecha en otra pantalla se refleja en la siguiente consulta.

## Instalación en Ubuntu
Ejemplo: addons personalizados en `/opt/odoo/custom-addons`. Ajusta la ruta a tu instalación real.

```bash
sudo mkdir -p /opt/odoo/custom-addons
sudo unzip bsoft_kitchen_display.zip -d /opt/odoo/custom-addons/
sudo chown -R odoo:odoo /opt/odoo/custom-addons/bsoft_kitchen_display
```

En `/etc/odoo.conf`, asegúrate de incluir la ruta en `addons_path`, por ejemplo:
```ini
addons_path = /opt/odoo/odoo/addons,/opt/odoo/custom-addons
```

Reinicia y revisa el log:
```bash
sudo systemctl restart odoo
sudo journalctl -u odoo -n 100 --no-pager
```

En Odoo: activa modo desarrollador → Apps → Actualizar lista → busca “BSOFT Kitchen Display” → Instalar. Asigna los grupos Cocinero, Encargado de cocina o Administrador de cocina a los usuarios. En el menú Kitchen Display crea estaciones, por ejemplo Cocina, Bebidas y Postres, y asigna categorías y puntos de venta.

## Actualización desde la versión anterior

Sustituye la carpeta `bsoft_kitchen_display` por la de este ZIP y actualiza el módulo, no solo el proceso Odoo: se añade el campo que guarda el inicio de etapa. En Apps, busca el módulo y usa **Actualizar**. Si prefieres línea de comandos, detén el servicio, ejecuta con el usuario de Odoo y la base correcta:

```bash
odoo -c /etc/odoo.conf -d NOMBRE_DE_TU_BASE -u bsoft_kitchen_display --stop-after-init
```

Después inicia de nuevo Odoo, recarga la página para cargar los assets nuevos y pulsa **Activar sonido**. Ajusta el ejecutable y rutas a tu instalación.

## Pruebas de aceptación
1. Crea categorías de TPV para cocina y bebidas; crea estaciones coincidentes.
2. Crea pedidos desde una sesión de TPV de prueba y confirma la asignación de líneas.
3. Comprueba el flujo Pendiente → Preparando → Listo → Entregado.
4. Abre dos pantallas y verifica que los cambios se reflejen en ambas.
5. Pulsa Activar sonido. Antes del minuto la tarjeta conserva su color normal; al minuto debe ponerse roja y sonar una sola vez. Avanza a Preparando y luego Listo, verificando el reinicio y la nueva alerta al minuto en cada etapa. Desactiva Sonido en la estación y comprueba que solo cambia el color.
6. Prueba permisos de cada grupo.
7. Prueba pedidos de restaurante con mesa, notas, variantes, descuentos, cancelaciones y devoluciones.
8. Revisa logs del servidor y consola del navegador.

## Alcance y advertencias de esta entrega
Esta entrega cambia el comportamiento de las alertas; no corrige los problemas de permisos y aislamiento entre empresas detectados en la validación anterior. Los grupos de cocina por sí solos no conceden escritura sobre `pos.order.line`, y la consulta existente con `sudo()` no restringe pedidos por empresa. Deben corregirse antes de uso operativo con esos roles o en varias empresas.

La pantalla consulta cada cinco segundos; no está suscrita a las notificaciones bus que emite el servidor. La asignación automática dirige cada línea a una sola estación (la primera que coincida); no duplica una línea en varias estaciones. Las particularidades de sincronización del TPV, notas y cancelaciones deben probarse contra la revisión exacta de Odoo 17 instalada. Haz copia de seguridad de base de datos y filestore antes de instalar en producción.
