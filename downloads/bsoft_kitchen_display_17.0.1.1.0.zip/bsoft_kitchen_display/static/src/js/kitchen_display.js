
/** @odoo-module **/

import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import {
    Component,
    onWillStart,
    onMounted,
    onWillUnmount,
    useState,
} from "@odoo/owl";

const LABELS = {
    new: "Pendiente",
    preparing: "Preparando",
    ready: "Listo",
    served: "Entregado",
};

const NEXT = {
    new: "preparing",
    preparing: "ready",
    ready: "served",
};

const BUTTONS = {
    new: "Comenzar preparación",
    preparing: "Marcar listo",
    ready: "Marcar entregado",
};

const ALERT_AFTER_MS = 60_000;

export class BsoftKitchenDisplay extends Component {
    static template = "bsoft_kitchen_display.KitchenDisplay";

    setup() {
        this.notification = useService("notification");

        this.state = useState({
            lines: [],
            stations: [],
            stationId: "all",
            loading: true,
            error: "",
            now: Date.now(),
            updatingIds: [],
            soundEnabled: false,
        });

        this.timer = null;
        this.clock = null;

        this.alertedStages = new Map();
        this.audioContext = null;
        this.audioStateChanged = () => {
            if (!this.destroyed) {
                this.state.soundEnabled = this.audioContext?.state === "running";
            }
        };

        this.loadingRequest = false;
        this.reloadPending = false;
        this.destroyed = false;

        onWillStart(async () => {
            await this.reload();
        });

        onMounted(() => {
            this.timer = setInterval(() => {
                void this.reload();
            }, 5000);

            this.clock = setInterval(() => {
                this.state.now = Date.now();
                this.checkAlerts();
            }, 1000);
        });

        onWillUnmount(() => {
            this.destroyed = true;

            if (this.timer) {
                clearInterval(this.timer);
                this.timer = null;
            }

            if (this.clock) {
                clearInterval(this.clock);
                this.clock = null;
            }
            if (this.audioContext) {
                this.audioContext.removeEventListener("statechange", this.audioStateChanged);
                void this.audioContext.close().catch(() => {});
            }
        });
    }

    async rpc(route, params = {}) {
        const response = await fetch(route, {
            method: "POST",
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                jsonrpc: "2.0",
                method: "call",
                params,
                id: Date.now(),
            }),
        });

        if (!response.ok) {
            throw new Error(`Error HTTP ${response.status}`);
        }

        const json = await response.json();

        if (json.error) {
            throw new Error(
                json.error.data?.message ||
                json.error.message ||
                "Error en la solicitud RPC"
            );
        }

        return json.result;
    }

    async reload() {
        if (this.destroyed) {
            return;
        }

        // Evitar solicitudes simultáneas sin perder la siguiente actualización.
        if (this.loadingRequest) {
            this.reloadPending = true;
            return;
        }

        this.loadingRequest = true;

        try {
            const stationId =
                this.state.stationId === "all"
                    ? false
                    : Number(this.state.stationId);

            const data = await this.rpc(
                "/bsoft_kitchen_display/data",
                { station_id: stationId }
            );

            if (this.destroyed) {
                return;
            }

            if (data?.error) {
                throw new Error(data.error);
            }

            const lines = data?.lines || [];
            const stations = data?.stations || [];

            this.state.lines = lines;
            this.state.stations = stations;
            this.state.now = Date.now();
            this.state.error = "";
            this.checkAlerts();
        } catch (error) {
            if (!this.destroyed) {
                this.state.error =
                    error.message ||
                    "No se pudieron cargar los pedidos";
            }
        } finally {
            this.loadingRequest = false;

            if (!this.destroyed) {
                this.state.loading = false;

                if (this.reloadPending) {
                    this.reloadPending = false;
                    void this.reload();
                }
            }
        }
    }

    async changeState(line) {
        const nextState = NEXT[line.state];

        if (
            !nextState ||
            this.state.updatingIds.includes(line.id)
        ) {
            return;
        }

        this.state.updatingIds.push(line.id);

        try {
            const result = await this.rpc(
                "/bsoft_kitchen_display/set_state",
                {
                    line_id: line.id,
                    state: nextState,
                }
            );

            if (result?.error) {
                throw new Error(result.error);
            }

            this.notification.add(
                "Pedido actualizado correctamente",
                { type: "success" }
            );

            await this.reload();
        } catch (error) {
            console.error(
                "Error al cambiar el estado:",
                error
            );

            this.state.error =
                error.message ||
                "No se pudo actualizar el pedido";

            this.notification.add(this.state.error, {
                type: "danger",
            });
        } finally {
            this.state.updatingIds =
                this.state.updatingIds.filter(
                    (id) => id !== line.id
                );
        }
    }

    setStation(event) {
        this.state.stationId = event.target.value;
        void this.reload();
    }

    label(state) {
        return LABELS[state] || state;
    }

    button(state) {
        return BUTTONS[state] || "Cambiar estado";
    }

    isUpdating(line) {
        return this.state.updatingIds.includes(line.id);
    }

    getTimestamp(line) {
        const start = line.stage_started_at || (
            line.state === "preparing" ? line.started_at :
            line.state === "ready" ? line.ready_at : line.created_at
        );

        if (!start) {
            return null;
        }

        const normalized = start.includes("T")
            ? start
            : start.replace(" ", "T");

        // Las fechas de Odoo sin zona horaria normalmente están en UTC.
        const hasTimezone =
            /(?:Z|[+-]\d{2}:\d{2})$/i.test(normalized);

        const timestamp = new Date(
            hasTimezone ? normalized : `${normalized}Z`
        ).getTime();

        return Number.isNaN(timestamp) ? null : timestamp;
    }

    elapsed(line) {
        const timestamp = this.getTimestamp(line);

        if (timestamp === null) {
            return "—";
        }

        const seconds = Math.max(
            0,
            Math.floor(
                (this.state.now - timestamp) / 1000
            )
        );

        return `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
    }

    ageClass(line) {
        const timestamp = this.getTimestamp(line);
        if (!(line.state in NEXT) || timestamp === null) {
            return "";
        }
        return this.state.now - timestamp >= ALERT_AFTER_MS ? "critical" : "";
    }

    checkAlerts() {
        if (this.destroyed || !this.state.soundEnabled) {
            return false;
        }
        const due = this.state.lines.filter((line) => {
            const station = this.state.stations.find((item) => item.id === line.station_id);
            const key = `${line.state}:${this.getTimestamp(line)}`;
            return this.ageClass(line) === "critical" && station?.sound !== false &&
                this.alertedStages.get(line.id) !== key;
        });
        // Coalesce simultaneous expirations into one audible signal.
        if (!due.length || !this.playAlert()) {
            return false;
        }
        for (const line of due) {
            this.alertedStages.set(line.id, `${line.state}:${this.getTimestamp(line)}`);
        }
        return true;
    }

    async enableSound() {
        try {
            const AudioContextClass = window.AudioContext || window.webkitAudioContext;
            if (!AudioContextClass) {
                throw new Error("Este navegador no admite las alertas de sonido.");
            }
            if (!this.audioContext || this.audioContext.state === "closed") {
                this.audioContext = new AudioContextClass();
                this.audioContext.addEventListener("statechange", this.audioStateChanged);
            }
            // Called from a real click to satisfy browser autoplay policies.
            await this.audioContext.resume();
            if (this.destroyed) {
                return;
            }
            if (this.audioContext.state !== "running") {
                throw new Error("El navegador bloqueó el audio. Revisa los permisos de sonido.");
            }
            this.state.soundEnabled = true;
            if (!this.checkAlerts()) {
                this.playAlert();
            }
        } catch (error) {
            if (!this.destroyed) {
                this.state.soundEnabled = false;
                this.notification.add(error.message || "No se pudo activar el sonido.", { type: "danger" });
            }
        }
    }

    playAlert() {
        const context = this.audioContext;
        if (!this.state.soundEnabled || context?.state !== "running") {
            return false;
        }
        try {
            for (const offset of [0, 0.3]) {
                const oscillator = context.createOscillator();
                const gain = context.createGain();
                oscillator.connect(gain);
                gain.connect(context.destination);
                oscillator.frequency.value = 880;
                const start = context.currentTime + offset;
                gain.gain.setValueAtTime(0, start);
                gain.gain.linearRampToValueAtTime(0.15, start + 0.01);
                gain.gain.linearRampToValueAtTime(0, start + 0.22);
                oscillator.start(start);
                oscillator.stop(start + 0.23);
                oscillator.onended = () => {
                    oscillator.disconnect();
                    gain.disconnect();
                };
            }
            return true;
        } catch (error) {
            this.state.soundEnabled = false;
            this.notification.add("No se pudo reproducir la alerta. Pulsa Activar sonido para reintentar.", { type: "danger" });
            return false;
        }
    }
}

registry.category("actions").add(
    "bsoft_kitchen_display",
    BsoftKitchenDisplay
);
